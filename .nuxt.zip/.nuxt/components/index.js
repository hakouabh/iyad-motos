export const About = () => import('../../components/About.vue' /* webpackChunkName: "components/about" */).then(c => wrapFunctional(c.default || c))
export const Brands = () => import('../../components/Brands.vue' /* webpackChunkName: "components/brands" */).then(c => wrapFunctional(c.default || c))
export const BtnScroll = () => import('../../components/BtnScroll.vue' /* webpackChunkName: "components/btn-scroll" */).then(c => wrapFunctional(c.default || c))
export const Contact = () => import('../../components/Contact.vue' /* webpackChunkName: "components/contact" */).then(c => wrapFunctional(c.default || c))
export const Entretien = () => import('../../components/Entretien.vue' /* webpackChunkName: "components/entretien" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../../components/Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const Header = () => import('../../components/Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const Home = () => import('../../components/Home.vue' /* webpackChunkName: "components/home" */).then(c => wrapFunctional(c.default || c))
export const Map = () => import('../../components/Map.vue' /* webpackChunkName: "components/map" */).then(c => wrapFunctional(c.default || c))
export const Shop = () => import('../../components/Shop.vue' /* webpackChunkName: "components/shop" */).then(c => wrapFunctional(c.default || c))
export const Showroom = () => import('../../components/Showroom.vue' /* webpackChunkName: "components/showroom" */).then(c => wrapFunctional(c.default || c))
export const Soon = () => import('../../components/Soon.vue' /* webpackChunkName: "components/soon" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
